# Simple Calculator in C

A menu-driven calculator written in C as a Semester 1 (B.Tech CSE) project.

**Author:** Ansh Kumar (Roll No: 29044)

## Features
- Addition, subtraction, multiplication, division
- Menu runs in a loop until the user chooses Exit
- Handles division by zero and invalid menu choices

## Concepts Used
Variables, `scanf`/`printf`, `if-else`, `switch-case`, `do-while` loop, functions.

## How to Compile and Run
```bash
gcc calculator.c -o calculator
./calculator        # On Windows: calculator.exe
```

## Sample Output
```
===== SIMPLE CALCULATOR =====
1. Addition
2. Subtraction
3. Multiplication
4. Division
5. Exit
Enter your choice (1-5): 1
Enter first number : 12
Enter second number: 8
Result: 12.00 + 8.00 = 20.00
```
